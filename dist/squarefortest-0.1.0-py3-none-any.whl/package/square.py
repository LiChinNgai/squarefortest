def square(a):
    result = a**2
    print(result)
    return result
