# Squarefortest

squaring input number